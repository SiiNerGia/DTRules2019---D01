package repositories;

import domain.Float;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FloatRepository extends JpaRepository<Float, Integer> {

}
